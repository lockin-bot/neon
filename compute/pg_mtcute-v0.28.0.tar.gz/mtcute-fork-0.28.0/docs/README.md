# mtcute docs

Documentation website for [mtcute](https://github.com/mtcute/mtcute), 
built with [VitePress](https://vitepress.dev/). 

## Development

```bash
pnpm install --frozen-lockfile
pnpm run dev
```
