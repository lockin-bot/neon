export interface MtkrutoSession {
  dcId: number
  isTest: boolean
  authKey: Uint8Array
}
